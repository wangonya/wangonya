+++
date = "2015-08-22T06:42:21-07:00"
draft = false
title = "Blog"
aliases = [
    "/posts/",
    "/writing/"
]

+++
